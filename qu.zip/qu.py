Q1:
create a function to retrieve all of the ingredints used in all Elixirs without 
 repetation then reorder the ingredients you found

output:
total ingredients used in all Exliris
Aconite
Acromantula venom
........


Q2:
you might notice a color when viewing "Exlirs" charachtiscs for ex: "characteristics":"purple colored"
provide a list of colors along with the count and names of all elixirs associated with each color
 if all elixir does not have a specified color, categorize it under "nocolor"

output:
Color (Purple):
[Elixirs count that has this color]
restoration potion
Color (yellow):
[Elixirs count that has this color]
skele-gro


hint: you need this __package__python -m pip install -U matplotlib

Note that the color might be in a sentence spereated by spaced like this
"characteristics": "Dark red in colour"
the color of this elixir is "red"
or seperated by space and "-" like this
"characteristics": "Dark blue-coloured in colour"
the color of this elixir is "blue"
