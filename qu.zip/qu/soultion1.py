import re

# Sample dataset of elixirs
elixirs = [
    {"name": "Restoration Potion", "ingredients": ["Aconite", "Lacewing Flies", "Fluxweed"], "characteristics": "purple colored"},
    {"name": "Skele-Gro", "ingredients": ["Chinese Chomping Cabbage", "Pufferfish Eyes"], "characteristics": "yellow colored"},
    {"name": "Polyjuice Potion", "ingredients": ["Lacewing Flies", "Leeches", "Fluxweed", "Knotgrass"], "characteristics": "Dark green in colour"},
    {"name": "Draught of Peace", "ingredients": ["Aconite", "Moonstone", "Hellebore"], "characteristics": "Light blue-coloured in colour"},
    {"name": "Pepperup Potion", "ingredients": ["Bicorn Horn", "Mandrake Root"], "characteristics": "No specific color mentioned"}
]

def analyze_elixirs(elixirs):
    # --- Q1: Unique Ingredients ---
    # Use a set to collect unique ingredients
    unique_ingredients = set()
    for elixir in elixirs:
        unique_ingredients.update(elixir["ingredients"])
    
    # Convert to list and sort alphabetically
    sorted_ingredients = sorted(list(unique_ingredients))
    
    # Print ingredients output
    print("total ingredients used in all Elixirs")
    for ingredient in sorted_ingredients:
        print(ingredient)
    
    # Add a separator for clarity
    print("\n" + "="*50 + "\n")
    
    # --- Q2: Colors and Elixir Counts ---
    # Dictionary to store colors and associated elixirs
    color_dict = {}
    
    # Common color names to look for
    color_names = ["purple", "yellow", "green", "blue", "red", "black", "white", "orange"]
    
    for elixir in elixirs:
        characteristics = elixir["characteristics"].lower()
        color_found = False
        
        # Search for color names in the characteristics
        for color in color_names:
            if re.search(rf"\b({color}(?:\s|-)?colou?r(?:ed)?)\b", characteristics):
                if color not in color_dict:
                    color_dict[color] = []
                color_dict[color].append(elixir["name"])
                color_found = True
                break
        
        # If no color is found, categorize as "nocolor"
        if not color_found:
            if "nocolor" not in color_dict:
                color_dict["nocolor"] = []
            color_dict["nocolor"].append(elixir["name"])
    
    # Print colors output
    for color, elixir_list in color_dict.items():
        print(f"Color ({color}):")
        print(f"[{len(elixir_list)}]")
        for elixir_name in elixir_list:
            print(elixir_name)

# Run the combined analysis
analyze_elixirs(elixirs)