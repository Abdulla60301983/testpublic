import re
from collections import defaultdict

# Sample data for elixirs
elixirs = [
    {"name": "Restoration Potion", "ingredients": ["Aconite", "Acromantula venom"], "characteristics": "purple colored"},
    {"name": "Skele-gro", "ingredients": ["Aconite", "Dragon blood"], "characteristics": "yellow in colour"},
    {"name": "Felix Felicis", "ingredients": ["Unicorn hair", "Acromantula venom"], "characteristics": "golden liquid"},
    {"name": "Polyjuice Potion", "ingredients": ["Boomslang skin", "Lacewing flies"], "characteristics": "Dark blue-coloured in colour"},
    {"name": "Elixir of Life", "ingredients": ["Phoenix feather", "Unicorn blood"], "characteristics": "No specific color"},
]

# Q1: Retrieve and reorder ingredients
def retrieve_and_reorder_ingredients(elixirs):
    unique_ingredients = set()
    for elixir in elixirs:
        unique_ingredients.update(elixir.get("ingredients", []))
    sorted_ingredients = sorted(unique_ingredients)
    print("Total ingredients used in all Elixirs:", len(sorted_ingredients))
    for ingredient in sorted_ingredients:
        print(ingredient)

# Q2: Extract colors and associated elixirs
def extract_colors_and_elixirs(elixirs):
    color_dict = defaultdict(list)
    color_pattern = re.compile(r"\b(red|blue|green|yellow|purple|orange|black|white|brown|pink)\b", re.IGNORECASE)
    for elixir in elixirs:
        characteristics = elixir.get("characteristics", "").lower()
        color_match = color_pattern.search(characteristics)
        if color_match:
            color = color_match.group(0)
            color_dict[color].append(elixir["name"])
        else:
            color_dict["nocolor"].append(elixir["name"])
    for color, elixirs_list in color_dict.items():
        print(f"Color ({color.capitalize()}):")
        print(f"[Elixirs count: {len(elixirs_list)}]")
        for elixir in elixirs_list:
            print(elixir)
        print()

# Run both functions
print("=== Q1: Ingredients ===")
retrieve_and_reorder_ingredients(elixirs)
print("\n=== Q2: Colors and Elixirs ===")
extract_colors_and_elixirs(elixirs)