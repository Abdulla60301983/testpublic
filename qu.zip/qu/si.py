import requests

# Fetch elixir data from the Wizard World API
def fetch_elixir_data():
    url = "https://wizard-world-api.herokuapp.com/Elixirs"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        with open("q1.txt", "w") as f:
            f.write(f"Failed to fetch data: {response.status_code}\n")
        with open("q2.txt", "w") as f:
            f.write(f"Failed to fetch data: {response.status_code}\n")
        return []

def analyze_elixirs():
    # Get the elixir data
    elixirs = fetch_elixir_data()
    if not elixirs:
        with open("q1.txt", "w") as f:
            f.write("No elixir data available.\n")
        with open("q2.txt", "w") as f:
            f.write("No elixir data available.\n")
        return

    # --- Q1: Unique Ingredients ---
    unique_ingredients = set()
    for elixir in elixirs:
        for ingredient in elixir.get("ingredients", []):
            unique_ingredients.add(ingredient["name"])
    
    # Sort ingredients
    sorted_ingredients = sorted(list(unique_ingredients))
    
    # Save to q1.txt
    with open("q1.txt", "w") as f:
        f.write("total ingredients used in all Elixirs\n")
        for ingredient in sorted_ingredients:
            f.write(f"{ingredient}\n")
    
    # --- Q2: Colors and Elixir Counts ---
    color_dict = {}
    color_names = ["purple", "yellow", "green", "blue", "red", "black", "white", "orange", "silver", "gold"]
    
    for elixir in elixirs:
        characteristics = elixir.get("characteristics", "") or ""
        characteristics = characteristics.lower()
        color_found = False
        
        # Simple string check for colors
        for color in color_names:
            if color in characteristics:
                if color not in color_dict:
                    color_dict[color] = []
                color_dict[color].append(elixir["name"])
                color_found = True
                break
        
        # If no color found, use "nocolor"
        if not color_found:
            if "nocolor" not in color_dict:
                color_dict["nocolor"] = []
            color_dict["nocolor"].append(elixir["name"])
    
    # Save to q2.txt
    with open("q2.txt", "w") as f:
        for color, elixir_list in color_dict.items():
            f.write(f"Color ({color}):\n")
            f.write(f"[{len(elixir_list)}]\n")
            for elixir_name in elixir_list:
                f.write(f"{elixir_name}\n")

# Run the analysis
analyze_elixirs()