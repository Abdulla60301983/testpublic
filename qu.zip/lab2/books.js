// Define an array of books
const books = [
    { title: "The Great Gatsby", author: "F. Scott Fitzgerald", year: 1925, price: 10.99 },
    { title: "To Kill a Mockingbird", author: "Harper Lee", year: 1960, price: 12.49 },
    { title: "1984", author: "George Orwell", year: 1949, price: 9.99 },
    { title: "Pride and Prejudice", author: "Jane Austen", year: 1813, price: 8.95 },
    { title: "The Catcher in the Rye", author: "J.D. Salinger", year: 1951, price: 11.75 },
    { title: "The Hobbit", author: "J.R.R. Tolkien", year: 1937, price: 14.99 },
    { title: "Brave New World", author: "Aldous Huxley", year: 1932, price: 10.25 },
    { title: "The Lord of the Rings", author: "J.R.R. Tolkien", year: 1954, price: 19.99 },
    { title: "Fahrenheit 451", author: "Ray Bradbury", year: 1953, price: 9.79 },
    { title: "Moby-Dick", author: "Herman Melville", year: 1851, price: 13.50 }
  ];
  
  // Define an object for managing book reviews
  const bookReviews = {
    "The Great Gatsby": "A masterpiece of American literature.",
    "To Kill a Mockingbird": "A poignant portrayal of social injustice.",
    "1984": "A dystopian classic that remains relevant today.",
    "Pride and Prejudice": "A timeless love story with sharp social commentary.",
    "The Catcher in the Rye": "A coming-of-age novel that captures teenage angst.",
    "The Hobbit": "A delightful adventure set in Middle-earth.",
    "Brave New World": "An exploration of a future society driven by technology.",
    "The Lord of the Rings": "An epic fantasy journey that defined the genre.",
    "Fahrenheit 451": "A cautionary tale about the dangers of censorship.",
    "Moby-Dick": "A symbolic exploration of obsession and the human spirit."
  };
  
  // Function to display book information
  function displayBookInfo(book) {
    console.log(`Title: ${book.title}`);
    console.log(`Author: ${book.author}`);
    console.log(`Year: ${book.year}`);
    console.log(`Price: $${book.price}`);
  }
  
  // Function to display book review
  function displayBookReview(title) {
    const review = bookReviews[title];
    if (review) {
      console.log(`Review for "${title}": ${review}`);
    } else {
      console.log(`No review available for "${title}".`);
    }
  }
  
  // Function to list all books
  function listBooks() {
    console.log("List of Books:");
    let index = 1;
    for (const book of books) {
      console.log(`${index}. ${book.title}`);
      index++;
    }
  }
  
  // Function to search for books within a price range
  function searchBooksByPrice(minPrice, maxPrice) {
    console.log(`Books within price range $${minPrice} - $${maxPrice}:`);
    for (const book of books) {
      if (book.price >= minPrice && book.price <= maxPrice) {
        console.log(`${book.title} - $${book.price}`);
      }
    }
  }
  
  // Call the displayBookInfo function with different books
  displayBookInfo(books[0]);
  displayBookInfo(books[2]);
  
  // Call the displayBookReview function for different books
  displayBookReview("The Great Gatsby");
  displayBookReview("1984");
  displayBookReview("To Kill a Mockingbird");
  displayBookReview("Moby-Dick");
  
  // Call the listBooks function to display all books
  listBooks();
  
  // Call the searchBooksByPrice function to find books within a price range
  searchBooksByPrice(10, 15);
  