const fs = require('fs/promises');

async function loadBooks() {
    let raw_data = await fs.readFile('books.csv', 'utf8');
    let lines = raw_data.split('\n');
    let result = [];
    for (l of lines) {
        if (l !== '') {
            let row = l.split(",");
            result.push({
                title: row[0],
                author: row[1],
                year: row[2],
                price: (Number(row[3]) + 2).toFixed(2) // Convert to number, add 2, and format to 2 decimal places
            });
        }
    }
    console.log(result);
    rewrite(result); // Corrected function name
}

async function rewrite(data) { // Corrected function name
    let content = data.map(book => `${book.title},${book.author},${book.year},${book.price}`).join('\n');
    await fs.writeFile('b1.csv', content); // Write the updated data to b1.csv
}

loadBooks();