const fs = require('fs/promises');

// Function to load books from the CSV file
async function loadBooks() {
    let raw_data = await fs.readFile('books.csv', 'utf8');
    let lines = raw_data.split('\n');
    let result = [];
    for (let l of lines) {
        if (l.trim() !== '') {
            let row = l.split(",");
            result.push({
                title: row[0],
                author: row[1],
                year: parseInt(row[2]), // Convert year to a number
                price: parseFloat(row[3]) // Convert price to a number
            });
        }
    }
    return result;
}

// Function to update book prices by adding $2
function updateBookPrices(books) {
    return books.map(book => {
        return {
            ...book,
            price: (book.price + 2).toFixed(2) 
        };
    });
}

// Function to write updated books back to the original CSV file
async function writeUpdatedBooks(books, outputFile) {
    let content = books.map(book => `${book.title},${book.author},${book.year},${book.price}`).join('\n');
    await fs.writeFile(outputFile, content);
}

// Main function to run the program
async function main() {
    try {
        // Step 1: Load books from the CSV file
        const books = await loadBooks();
        console.log("Original Books:", books);

        // Step 2: Update book prices
        const updatedBooks = updateBookPrices(books);
        console.log("Updated Books:", updatedBooks);

        // Step 3: Write updated books back to the original file (books.csv)
        await writeUpdatedBooks(updatedBooks, 'books.csv');
        console.log("Updated books have been written to 'books.csv'.");
    } catch (error) {
        console.error("An error occurred:", error);
    }
}

// Run the program
main();