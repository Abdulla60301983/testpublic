import requests
response = requests.get("https://udst.edu.qa/abc")
print(response.status_code)
print(type(response))
#print(response.content)
